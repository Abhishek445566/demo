package com.recruitment.proxy;


import org.springframework.web.bind.annotation.RequestMapping;

public interface ServiceProxy {
	
	   public String greeting();
}
