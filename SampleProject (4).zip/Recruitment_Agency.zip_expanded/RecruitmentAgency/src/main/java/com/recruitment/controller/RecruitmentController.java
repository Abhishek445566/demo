package com.recruitment.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.recruitment.exception.CandidateAlreadyExistsException;
import com.recruitment.model.Candidate;
import com.recruitment.service.IRecruitmentService;
import com.recruitment.validation.RecruitmentValidator;

@RestController
public class RecruitmentController {
	
	@Autowired
	private IRecruitmentService irecruit;
	
//	@Autowired
//	private RecruitmentValidator recruitValidator;
//	
	
	@PostMapping("/register")
	public Candidate registerCandidate(@RequestBody @Valid Candidate candidate) throws CandidateAlreadyExistsException{
		Candidate registerCandidate = irecruit.registerCandidate(candidate);
		return registerCandidate;
	}
	
	@GetMapping("/view")
	public Map<String,List<Candidate>> viewCandidateBasedonPosition(){
		Map<String, List<Candidate>> position = irecruit.viewCandidateBasedonPosition();
		return position;
	}
	
	@GetMapping("/filter/{yearsOfExperience}")
	public List<Candidate> filterCandidate(@PathVariable int yearsOfExperience){
		List<Candidate> filterCandidate = irecruit.filterCandidate(yearsOfExperience);
		return filterCandidate;		
	}
	
	@DeleteMapping("/remove")
	public int removeCandidate() {
		int removedCount = irecruit.removeCandidate();
		return removedCount;
	}
}

