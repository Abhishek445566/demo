package com.recruitment.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.recruitment.exception.CandidateAlreadyExistsException;
import com.recruitment.model.Candidate;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class RecruitmentServiceImpl implements IRecruitmentService {

	private static List<Candidate> candidateList=new ArrayList<Candidate>();
	
	/*
	 * This method should add the candidate object to the candidateList, before adding it shoulkd check
	 * whether the email id of the candidate is already available, if available throw an exception
	 * else add the candidate object into the list
	 */
	public Candidate registerCandidate(Candidate candidate) throws CandidateAlreadyExistsException {
		// TODO Auto-generated method stub
		Candidate candi = new Candidate();
		candi.setCandidateId(candidate.getCandidateId());
		candi.setCandidateName(candidate.getCandidateName());
		candi.setEmailId(candidate.getEmailId());
		candi.setExpectedSalary(candidate.getExpectedSalary());
		candi.setMobileNumber(candidate.getMobileNumber());
		candi.setStatus(candidate.getStatus());
		
		if(candidate.getYearsOfExperience() >0) {
			candi.setPositionAppliedFor(candidate.getPositionAppliedFor());
			candi.setYearsOfExperience(candidate.getYearsOfExperience());
		}
		else if(candidate.getYearsOfExperience() <=0) {
			candi.setPositionAppliedFor("fresher");
			candi.setYearsOfExperience(0);
		}

		Predicate<? super Candidate> predicate = candidate1 -> candidate1.getEmailId()
				.equalsIgnoreCase(candi.getEmailId());
		boolean present = candidateList.stream().filter(predicate).findAny().isPresent();

		if (!present) {
			candidateList.add(candi);
		} else {
			log.error("*****Candidate is already exists*******", new CandidateAlreadyExistsException("Candidate is already exists"));
			throw new CandidateAlreadyExistsException("Candidate is already exists");
		}
		return candi;
	}

	/*
	 * This method should return the Map as position applied for as a key and list of candidates who applied for that position as value.
	 */
	public Map<String, List<Candidate>> viewCandidateBasedonPosition() {
		Map<String, List<Candidate>> collect = candidateList.stream()
				.collect(Collectors.groupingBy(Candidate::getPositionAppliedFor));

		return collect;
	}

	/*
	 * This method should accept the years of experience as input and it should  
	 *  iterate the candidateList and return the list of candidates who have that experience.
	 */
	public List<Candidate> filterCandidate(int yearsOfExperience) {
		Predicate<? super Candidate> predicate = candidate -> candidate.getYearsOfExperience() == yearsOfExperience;
		List<Candidate> collect = candidateList.stream().filter(predicate).collect(Collectors.toList());
		return collect;
	}

	
	/*
	 * This method should remove the candidate based on the status. 
	 * If the status is recruited then remove all those candidates.
	 * This method should return the number of candidates removed.
	 */
	public int removeCandidate() {
		Predicate<? super Candidate> predicate = candidate -> candidate.getStatus().equalsIgnoreCase("recruited");
		List<Candidate> newList = new ArrayList<>();
		int count = (int) candidateList.stream().filter(predicate).count();
		candidateList.stream().filter(predicate).forEach(candidate -> newList.add(candidate));
		candidateList.removeAll(newList);
		return count;
	}

	
	
	public static List<Candidate> getCandidateList() {
		return candidateList;
	}

	public static void setCandidateList(List<Candidate> candidateList) {
		RecruitmentServiceImpl.candidateList = candidateList;
	}

	
}
