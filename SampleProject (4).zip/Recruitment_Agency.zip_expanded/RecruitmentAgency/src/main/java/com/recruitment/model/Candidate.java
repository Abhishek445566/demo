package com.recruitment.model;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class Candidate {
	
	@NotEmpty(message="Provide value for candidate Id")
	private String candidateId	;
	
	private String candidateName;
	
	@NotBlank(message="Provide value for mobile number")
	private String mobileNumber	;
	
	@Email(message="Provide value for email Id")
	private String emailId	;
	private String positionAppliedFor	;
	private Integer yearsOfExperience	;
	
	@NotNull(message="Provide value greater than or equal to zero")
	@Min(value = 0)
	private double expectedSalary	;
	
	private String Status	;


	





	public Candidate() {
		
	}

	public Candidate(String candidateId, String candidateName, String mobileNumber, String emailId,
			String positionAppliedFor, Integer yearsOfExperience, double expectedSalary, String status) {
		super();
		this.candidateId = candidateId;
		this.candidateName = candidateName;
		this.mobileNumber = mobileNumber;
		this.emailId = emailId;
		this.positionAppliedFor = positionAppliedFor;
		this.yearsOfExperience = yearsOfExperience;
		this.expectedSalary = expectedSalary;
		Status = status;
	}

}
